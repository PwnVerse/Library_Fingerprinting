# Rustls Provider Tests

This crate is an unpublished workspace crate that holds integration tests for different cryptography providers
and associated machinery. We add tests here to avoid taking heavy dependencies on the main rustls crate.
