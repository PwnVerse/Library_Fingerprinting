+++
title = "Performance reports"
sort_by = "date"
template = "reports.html"
page_template = "report-page.html"
+++

See also: [documentation of other kinds of benchmarking we do](https://github.com/rustls/rustls/blob/main/BENCHMARKING.md).

